import type { College } from './engineeringColleges';

export const dentalColleges: College[] = [
  {
    id: "bangalore-institute",
    name: "Bangalore Institute of Dental Science",
    shortDescription: "In 1991, the Institution was established under the dynamic direction of Dr. K S Naresh, a renowned Oral & Maxillofacial Surgeon.",
    fullDescription: "Bangalore Institute of Dental Sciences (BIDS) was established in 1991 under the dynamic direction of Dr. K S Naresh, a renowned Oral & Maxillofacial Surgeon. The institution offers BDS (Bachelor of Dental Surgery) and MDS (Master of Dental Surgery) programs and is affiliated to the Rajiv Gandhi University of Health Sciences (RGUHS). BIDS is recognized by the Dental Council of India (DCI) and is committed to providing quality dental education and comprehensive clinical training. The college has state-of-the-art infrastructure, well-equipped laboratories, and experienced faculty members.",
    image: "https://ext.same-assets.com/2614824330/3288964529.jpeg",
    location: "Hosur Road, Bangalore",
    established: "1991",
    featured: true,
    courses: ["BDS (Bachelor of Dental Surgery)", "MDS (Master of Dental Surgery)"],
    departments: [
      "Oral Medicine and Radiology",
      "Oral and Maxillofacial Surgery",
      "Conservative Dentistry and Endodontics",
      "Orthodontics and Dentofacial Orthopedics",
      "Pedodontics and Preventive Dentistry",
      "Periodontics",
      "Prosthodontics and Crown & Bridge",
      "Public Health Dentistry",
      "Oral Pathology and Microbiology"
    ],
    facilities: [
      "Modern Dental Clinics",
      "Advanced Laboratories",
      "Digital Radiography",
      "Library",
      "Hostels",
      "Sports Facilities",
      "Cafeteria",
      "Transportation"
    ],
    admissionProcess: "Bangalore Institute of Dental Sciences offers admissions through NEET (National Eligibility cum Entrance Test) for government quota seats. Management quota seats are also available for direct admission. The process for management quota involves submitting an application to the college, followed by document verification and seat allotment based on availability.",
    feeStructure: "The annual fee for BDS program under management quota ranges from ₹4,00,000 to ₹5,00,000. For MDS programs, the fees range from ₹6,00,000 to ₹8,00,000 per annum. For NRI/Foreign students, the fees are higher.",
    eligibility: "For BDS program, candidates must have passed 10+2 with Physics, Chemistry, and Biology with a minimum aggregate of 50% marks (40% for SC/ST candidates) and should have qualified NEET. For MDS programs, candidates should have a BDS degree with at least one year of compulsory rotating internship and should have qualified NEET MDS.",
    contactInfo: {
      phone: "+91 8118935934",
      email: "info@bangaloreadmissionhub.com",
      website: "https://www.bids.edu.in",
      address: "5/9, Hosur Road, Bengaluru - 560029, Karnataka, India"
    }
  },
  {
    id: "rv-dental",
    name: "RV Dental College",
    shortDescription: "RV Dental College Admission, Rashtreeya Sikshana Samithi Trust was founded to provide quality dental education.",
    fullDescription: "RV Dental College, officially known as S. Nijalingappa Institute of Dental Sciences & Research, is run by the Rashtreeya Sikshana Samithi Trust (RSST). The college offers BDS and MDS programs and is affiliated to Rajiv Gandhi University of Health Sciences (RGUHS). RV Dental College is recognized by the Dental Council of India (DCI) and is committed to providing quality dental education with a focus on practical training. The college has modern infrastructure, well-equipped clinics, and experienced faculty members.",
    image: "https://ext.same-assets.com/2614824330/1545761655.jpeg",
    location: "Bengaluru, Karnataka",
    established: "1992",
    featured: true,
    courses: ["BDS (Bachelor of Dental Surgery)", "MDS (Master of Dental Surgery)"],
    departments: [
      "Oral Medicine and Radiology",
      "Oral and Maxillofacial Surgery",
      "Conservative Dentistry and Endodontics",
      "Orthodontics and Dentofacial Orthopedics",
      "Pedodontics and Preventive Dentistry",
      "Periodontics",
      "Prosthodontics and Crown & Bridge",
      "Public Health Dentistry",
      "Oral Pathology and Microbiology"
    ],
    facilities: [
      "Modern Dental Clinics",
      "Advanced Laboratories",
      "Digital Radiography",
      "Library",
      "Hostels",
      "Sports Facilities",
      "Cafeteria",
      "Transportation"
    ],
    admissionProcess: "RV Dental College offers admissions through NEET for government quota seats. Management quota seats are also available for direct admission. The process for management quota involves submitting an application to the college, followed by document verification and seat allotment based on availability.",
    feeStructure: "The annual fee for BDS program under management quota ranges from ₹4,50,000 to ₹5,50,000. For MDS programs, the fees range from ₹7,00,000 to ₹9,00,000 per annum. For NRI/Foreign students, the fees are higher.",
    eligibility: "For BDS program, candidates must have passed 10+2 with Physics, Chemistry, and Biology with a minimum aggregate of 50% marks (40% for SC/ST candidates) and should have qualified NEET. For MDS programs, candidates should have a BDS degree with at least one year of compulsory rotating internship and should have qualified NEET MDS.",
    contactInfo: {
      phone: "+91 8118935934",
      email: "info@bangaloreadmissionhub.com",
      website: "https://www.rvdental.edu.in",
      address: "CA 37, 24th Main, JP Nagar 1st Phase, Bengaluru - 560078, Karnataka, India"
    }
  },
  {
    id: "ms-ramaiah-dental",
    name: "MS Ramaiah Dental College",
    shortDescription: "It is located in the MS Ramaiah Dental College is affiliated to the Rajiv Gandhi University of Health Sciences.",
    fullDescription: "M.S. Ramaiah Dental College & Hospital was established in 1991 by the late Dr. M.S. Ramaiah, a visionary philanthropist. The college offers BDS and MDS programs and is affiliated to Rajiv Gandhi University of Health Sciences (RGUHS). MS Ramaiah Dental College is recognized by the Dental Council of India (DCI) and is known for its excellent academic standards and clinical training. The college has state-of-the-art infrastructure, well-equipped clinics, and experienced faculty members.",
    image: "https://ext.same-assets.com/2614824330/2504202612.jpeg",
    location: "MSRIT Post, Bengaluru",
    established: "1991",
    featured: false,
    courses: ["BDS (Bachelor of Dental Surgery)", "MDS (Master of Dental Surgery)"],
    departments: [
      "Oral Medicine and Radiology",
      "Oral and Maxillofacial Surgery",
      "Conservative Dentistry and Endodontics",
      "Orthodontics and Dentofacial Orthopedics",
      "Pedodontics and Preventive Dentistry",
      "Periodontics",
      "Prosthodontics and Crown & Bridge",
      "Public Health Dentistry",
      "Oral Pathology and Microbiology"
    ],
    facilities: [
      "Modern Dental Clinics",
      "Advanced Laboratories",
      "Digital Radiography",
      "Library",
      "Hostels",
      "Sports Facilities",
      "Cafeteria",
      "Transportation"
    ],
    admissionProcess: "MS Ramaiah Dental College offers admissions through NEET for government quota seats. Management quota seats are also available for direct admission. The process for management quota involves submitting an application to the college, followed by document verification and seat allotment based on availability.",
    feeStructure: "The annual fee for BDS program under management quota ranges from ₹4,50,000 to ₹5,50,000. For MDS programs, the fees range from ₹7,00,000 to ₹9,00,000 per annum. For NRI/Foreign students, the fees are higher.",
    eligibility: "For BDS program, candidates must have passed 10+2 with Physics, Chemistry, and Biology with a minimum aggregate of 50% marks (40% for SC/ST candidates) and should have qualified NEET. For MDS programs, candidates should have a BDS degree with at least one year of compulsory rotating internship and should have qualified NEET MDS.",
    contactInfo: {
      phone: "+91 8118935934",
      email: "info@bangaloreadmissionhub.com",
      website: "https://www.msramaiah.org",
      address: "MSRIT Post, MSR Nagar, Bengaluru - 560054, Karnataka, India"
    }
  },
  {
    id: "vydehi-institute",
    name: "Vydehi Institute of Dental Sciences",
    shortDescription: "According to the famous quote of Sir William Osler, 'The practice of medicine is an art, not a trade; a calling, not a business.'",
    fullDescription: "Vydehi Institute of Dental Sciences and Research Centre is a part of Vydehi Institute of Medical Sciences and Research Centre. The college offers BDS and MDS programs and is affiliated to Rajiv Gandhi University of Health Sciences (RGUHS). Vydehi Institute of Dental Sciences is recognized by the Dental Council of India (DCI) and is committed to providing quality dental education and comprehensive clinical training. The college has state-of-the-art infrastructure, well-equipped clinics, and experienced faculty members.",
    image: "https://ext.same-assets.com/2614824330/3712174349.jpeg",
    location: "Whitefield, Bengaluru",
    established: "2002",
    featured: false,
    courses: ["BDS (Bachelor of Dental Surgery)", "MDS (Master of Dental Surgery)"],
    departments: [
      "Oral Medicine and Radiology",
      "Oral and Maxillofacial Surgery",
      "Conservative Dentistry and Endodontics",
      "Orthodontics and Dentofacial Orthopedics",
      "Pedodontics and Preventive Dentistry",
      "Periodontics",
      "Prosthodontics and Crown & Bridge",
      "Public Health Dentistry",
      "Oral Pathology and Microbiology"
    ],
    facilities: [
      "Modern Dental Clinics",
      "Advanced Laboratories",
      "Digital Radiography",
      "Library",
      "Hostels",
      "Sports Facilities",
      "Cafeteria",
      "Transportation"
    ],
    admissionProcess: "Vydehi Institute of Dental Sciences offers admissions through NEET for government quota seats. Management quota seats are also available for direct admission. The process for management quota involves submitting an application to the college, followed by document verification and seat allotment based on availability.",
    feeStructure: "The annual fee for BDS program under management quota ranges from ₹4,00,000 to ₹5,00,000. For MDS programs, the fees range from ₹6,50,000 to ₹8,50,000 per annum. For NRI/Foreign students, the fees are higher.",
    eligibility: "For BDS program, candidates must have passed 10+2 with Physics, Chemistry, and Biology with a minimum aggregate of 50% marks (40% for SC/ST candidates) and should have qualified NEET. For MDS programs, candidates should have a BDS degree with at least one year of compulsory rotating internship and should have qualified NEET MDS.",
    contactInfo: {
      phone: "+91 8118935934",
      email: "info@bangaloreadmissionhub.com",
      website: "https://www.vids.ac.in",
      address: "EPIP Area, Whitefield, Bengaluru - 560066, Karnataka, India"
    }
  }
];
