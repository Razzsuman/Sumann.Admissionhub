export interface College {
  id: string;
  name: string;
  shortDescription: string;
  fullDescription: string;
  image: string;
  location: string;
  ranking?: string;
  established?: string;
  featured?: boolean;
  courses?: string[];
  departments?: string[];
  facilities?: string[];
  admissionProcess?: string;
  feeStructure?: string;
  eligibility?: string;
  contactInfo?: {
    phone?: string;
    email?: string;
    website?: string;
    address?: string;
  };
}

export const engineeringColleges: College[] = [
  {
    id: "rv-college",
    name: "RV College Of Engineering",
    shortDescription: "Rashtreeya Vidyalaya College of Engineering (RVCE) is a premier institution in Bangalore.",
    fullDescription: "Rashtreeya Vidyalaya College of Engineering (RVCE) established in 1963 is one of the earliest self-financing engineering colleges in India. The institution is run by Rashtreeya Sikshana Samiti Trust (RSST) a not-for-profit trust. RV College of Engineering is today recognized as one of India's leading technical institutions. RVCE offers a Bachelor of Engineering (BE) degree in 12 disciplines and a Bachelor of Architecture degree. The college offers a Master of Technology (M.Tech.) degree in 21 disciplines and a Master of Computer Applications (MCA) degree. All departments have been recognized as research centers offering Doctor of Philosophy (Ph.D) degree by Visvesvaraya Technological University (VTU) in Science and Engineering disciplines.",
    image: "https://ext.same-assets.com/2614824330/1545761655.jpeg",
    location: "Bengaluru, Karnataka",
    ranking: "NIRF Rank: 13",
    established: "1963",
    featured: true,
    courses: ["B.E. in Computer Science", "B.E. in Electronics & Communication", "B.E. in Mechanical Engineering", "B.E. in Civil Engineering", "B.E. in Information Science", "M.Tech Programs", "Ph.D Programs"],
    departments: [
      "Computer Science and Engineering",
      "Electronics and Communication Engineering",
      "Mechanical Engineering",
      "Civil Engineering",
      "Information Science and Engineering",
      "Electrical and Electronics Engineering",
      "Industrial Engineering and Management",
      "Chemical Engineering",
      "Biotechnology",
      "Aerospace Engineering",
      "Master of Computer Applications"
    ],
    facilities: [
      "Modern Laboratories",
      "Central Library",
      "Sports Complex",
      "Placement Cell",
      "Hostels for Boys and Girls",
      "Transportation",
      "Cafeteria",
      "Medical Facility"
    ],
    admissionProcess: "Admission to RV College of Engineering is primarily through entrance exams like KCET, COMEDK, and JEE. However, management quota seats are also available for direct admission. The management quota admission process involves submitting an application directly to the college, followed by document verification and seat allotment based on availability.",
    feeStructure: "The annual fee for B.E. programs under management quota ranges from ₹2,50,000 to ₹3,00,000. For NRI/Foreign students, the fees are higher. M.Tech program fees range from ₹1,50,000 to ₹2,00,000 per annum.",
    eligibility: "For B.E. programs, candidates must have passed 10+2 with Physics, Chemistry, and Mathematics with a minimum aggregate of 45% marks (40% for SC/ST candidates). For M.Tech programs, candidates should have a B.E./B.Tech degree with at least 50% marks.",
    contactInfo: {
      phone: "+91 8118935934",
      email: "info@bangaloreadmissionhub.com",
      website: "https://www.rvce.edu.in",
      address: "RV Vidyanikethan Post, Mysuru Road, Bengaluru - 560059, Karnataka, India"
    }
  },
  {
    id: "bms-college",
    name: "BMS College of Engineering",
    shortDescription: "BMS College of Engineering (BMSCE) is an autonomous engineering college in Bangalore.",
    fullDescription: "BMS College of Engineering (BMSCE) was established in 1946 and is one of the oldest private engineering colleges in India. Located in Basavangudi, Bangalore, BMSCE offers undergraduate, post-graduate, and doctorate courses in various engineering fields. It is autonomous under Visvesvaraya Technological University (VTU) and is accredited by the National Board of Accreditation (NBA). The college is ranked among the top engineering colleges in India and is known for its academic excellence and quality education.",
    image: "https://ext.same-assets.com/2614824330/136836748.jpeg",
    location: "Basavangudi, Bengaluru",
    ranking: "NIRF Rank: 67",
    established: "1946",
    featured: true,
    courses: ["B.E. in Computer Science", "B.E. in Electronics & Communication", "B.E. in Mechanical Engineering", "B.E. in Civil Engineering", "B.E. in Information Science", "M.Tech Programs", "Ph.D Programs"],
    departments: [
      "Aerospace Engineering",
      "Architecture",
      "Biotechnology",
      "Chemical Engineering",
      "Chemistry",
      "Civil Engineering",
      "Computer Science and Engineering",
      "Electrical and Electronics Engineering",
      "Electronics and Communication Engineering",
      "Industrial Engineering and Management",
      "Information Science and Engineering",
      "Mathematics",
      "Mechanical Engineering",
      "Physics",
      "Telecommunication Engineering"
    ],
    facilities: [
      "Hospital",
      "Library",
      "Placement Cell",
      "Sports Facilities",
      "Hostels",
      "Cafeteria",
      "Wi-Fi Campus",
      "Laboratories"
    ],
    admissionProcess: "BMS College of Engineering offers admissions through entrance exams like KCET and COMEDK. Additionally, there are management quota seats available for direct admission. For management quota, applicants need to submit their application to the college, attend counseling, and secure admission based on seat availability.",
    feeStructure: "The approximate annual fee for B.E. programs under management quota is between ₹2,00,000 to ₹2,50,000. For NRI quota, the fees are approximately ₹4,00,000 to ₹5,00,000 per annum.",
    eligibility: "For B.E. programs, candidates must have completed 10+2 with Physics, Chemistry, and Mathematics with a minimum of 45% aggregate marks (40% for SC/ST candidates).",
    contactInfo: {
      phone: "+91 8118935934",
      email: "info@bangaloreadmissionhub.com",
      website: "https://www.bmsce.ac.in",
      address: "Bull Temple Road, Basavangudi, Bengaluru - 560019, Karnataka, India"
    }
  },
  {
    id: "ms-ramaiah",
    name: "MS Ramaiah Institute of Technology",
    shortDescription: "MS Ramaiah Institute of Technology (MSRIT) is a leading engineering institution in Bangalore.",
    fullDescription: "M.S. Ramaiah Institute of Technology (MSRIT) is an autonomous engineering college located in Bangalore, Karnataka, India. It was established in 1962 by the late Dr. M. S. Ramaiah, a renowned industrialist and philanthropist. MSRIT is affiliated to the Visvesvaraya Technological University (VTU) and is accredited by the National Board of Accreditation (NBA). The college offers undergraduate, postgraduate, and doctoral programs in various engineering disciplines. MSRIT is consistently ranked among the top engineering colleges in India and is known for its excellent faculty, research facilities, and industry connections.",
    image: "https://ext.same-assets.com/2614824330/584414836.jpeg",
    location: "Mathikere, Bengaluru",
    ranking: "NIRF Rank: 78",
    established: "1962",
    featured: false,
    courses: ["B.E. in Computer Science", "B.E. in Information Science", "B.E. in Electronics & Communication", "B.E. in Mechanical Engineering", "B.E. in Civil Engineering", "M.Tech Programs", "Ph.D Programs"],
    departments: [
      "Civil Engineering",
      "Mechanical Engineering",
      "Electrical and Electronics Engineering",
      "Computer Science and Engineering",
      "Electronics and Communication Engineering",
      "Chemical Engineering",
      "Industrial Engineering and Management",
      "Information Science and Engineering",
      "Medical Electronics",
      "Biotechnology",
      "Artificial Intelligence and Machine Learning"
    ],
    facilities: [
      "Central Library",
      "Sports Complex",
      "Hostels",
      "Transportation",
      "Cafeteria",
      "Medical Center",
      "Placement Cell",
      "Research Centers"
    ],
    admissionProcess: "MS Ramaiah Institute of Technology offers admissions through KCET and COMEDK entrance exams. Management quota seats are also available for direct admission. The process for management quota involves submitting an application to the college, followed by a counseling session and seat allotment.",
    feeStructure: "The annual fee for B.E. programs under management quota is approximately ₹2,00,000 to ₹2,50,000. For NRI/Foreign students, the fees are higher, ranging from ₹3,50,000 to ₹4,50,000 per annum.",
    eligibility: "For B.E. programs, candidates should have passed 10+2 with Physics, Chemistry, and Mathematics with a minimum aggregate of 45% marks (40% for SC/ST candidates).",
    contactInfo: {
      phone: "+91 8118935934",
      email: "info@bangaloreadmissionhub.com",
      website: "https://www.msrit.edu",
      address: "MSR Nagar, MSRIT Post, Bengaluru - 560054, Karnataka, India"
    }
  },
  {
    id: "dayananda-sagar",
    name: "Dayananda Sagar College Of Engineering",
    shortDescription: "Established in 1979, Dayananda Sagar College of Engineering is among the top colleges in Bangalore.",
    fullDescription: "Dayananda Sagar College of Engineering (DSCE) was established in 1979 and is run by the Dayananda Sagar Institutions. The college is affiliated to Visvesvaraya Technological University (VTU) and is approved by AICTE. DSCE offers undergraduate, postgraduate, and doctoral programs in engineering, technology, and management. The college has state-of-the-art infrastructure, well-equipped laboratories, and a strong focus on research and development. DSCE is known for its industry connections and placement opportunities.",
    image: "https://ext.same-assets.com/2614824330/3181667196.jpeg",
    location: "Kumaraswamy Layout, Bengaluru",
    ranking: "Top 100 in India",
    established: "1979",
    featured: false,
    courses: ["B.E. in Computer Science", "B.E. in Information Science", "B.E. in Electronics & Communication", "B.E. in Mechanical Engineering", "B.E. in Civil Engineering", "M.Tech Programs", "Ph.D Programs"],
    departments: [
      "Computer Science and Engineering",
      "Information Science and Engineering",
      "Electronics and Communication Engineering",
      "Electrical and Electronics Engineering",
      "Mechanical Engineering",
      "Civil Engineering",
      "Chemical Engineering",
      "Biotechnology",
      "Artificial Intelligence and Machine Learning",
      "Data Science"
    ],
    facilities: [
      "Central Library",
      "Sports Complex",
      "Hostels",
      "Transportation",
      "Cafeteria",
      "Medical Center",
      "Placement Cell",
      "Innovation Center"
    ],
    admissionProcess: "Dayananda Sagar College of Engineering offers admissions through entrance exams like KCET and COMEDK. Management quota seats are also available for direct admission. The process for management quota admission involves submitting an application directly to the college, followed by document verification and seat allotment.",
    feeStructure: "The annual fee for B.E. programs under management quota ranges from ₹1,75,000 to ₹2,25,000. For NRI quota, the fees are approximately ₹3,00,000 to ₹4,00,000 per annum.",
    eligibility: "For B.E. programs, candidates must have passed 10+2 with Physics, Chemistry, and Mathematics with a minimum aggregate of 45% marks (40% for SC/ST candidates).",
    contactInfo: {
      phone: "+91 8118935934",
      email: "info@bangaloreadmissionhub.com",
      website: "https://www.dayanandasagar.edu",
      address: "Shavige Malleshwara Hills, Kumaraswamy Layout, Bengaluru - 560078, Karnataka, India"
    }
  },
  {
    id: "sapthagiri-college",
    name: "Sapthagiri College of Engineering",
    shortDescription: "Sapthagiri College of Engineering is located in Bangalore and offers quality education.",
    fullDescription: "Sapthagiri College of Engineering (SCE) was established in 2001 and is affiliated to Visvesvaraya Technological University (VTU), approved by AICTE, and accredited by NAAC. The college offers undergraduate and postgraduate programs in various engineering disciplines. SCE is known for its academic excellence, experienced faculty, and state-of-the-art infrastructure. The college has strong industry connections, which helps students in placements and internships.",
    image: "https://ext.same-assets.com/2614824330/389642620.png",
    location: "Chikkasandra, Bengaluru",
    ranking: "Top 150 in India",
    established: "2001",
    featured: false,
    courses: ["B.E. in Computer Science", "B.E. in Information Science", "B.E. in Electronics & Communication", "B.E. in Mechanical Engineering", "B.E. in Civil Engineering", "M.Tech Programs"],
    departments: [
      "Computer Science and Engineering",
      "Information Science and Engineering",
      "Electronics and Communication Engineering",
      "Electrical and Electronics Engineering",
      "Mechanical Engineering",
      "Civil Engineering",
      "Artificial Intelligence and Machine Learning"
    ],
    facilities: [
      "Library",
      "Sports Facilities",
      "Hostels",
      "Transportation",
      "Cafeteria",
      "Laboratories",
      "Placement Cell"
    ],
    admissionProcess: "Sapthagiri College of Engineering offers admissions through KCET and COMEDK entrance exams. Management quota seats are also available for direct admission. For management quota, applicants need to contact the college directly and go through the admission process which includes document verification and seat allotment.",
    feeStructure: "The annual fee for B.E. programs under management quota is approximately ₹1,50,000 to ₹2,00,000. For NRI quota, the fees are approximately ₹2,50,000 to ₹3,50,000 per annum.",
    eligibility: "For B.E. programs, candidates must have passed 10+2 with Physics, Chemistry, and Mathematics with a minimum aggregate of 45% marks (40% for SC/ST candidates).",
    contactInfo: {
      phone: "+91 8118935934",
      email: "info@bangaloreadmissionhub.com",
      website: "https://www.sapthagiri.edu.in",
      address: "No. 14/5, Chikkasandra, Hesarghatta Main Road, Bengaluru - 560057, Karnataka, India"
    }
  },
  {
    id: "atria-institute",
    name: "Atria Institute of Technology",
    shortDescription: "Atria Institute of Technology offers engineering programs with modern facilities.",
    fullDescription: "Atria Institute of Technology was established in 2000 and is affiliated to Visvesvaraya Technological University (VTU) and approved by AICTE. The institute offers undergraduate and postgraduate programs in engineering and management. Atria is known for its focus on innovation, research, and entrepreneurship. The college has state-of-the-art infrastructure, well-equipped laboratories, and experienced faculty.",
    image: "https://ext.same-assets.com/2614824330/3513203306.jpeg",
    location: "Anandnagar, Bengaluru",
    established: "2000",
    featured: false,
    courses: ["B.E. in Computer Science", "B.E. in Information Science", "B.E. in Electronics & Communication", "B.E. in Mechanical Engineering", "B.E. in Civil Engineering", "MBA"],
    departments: [
      "Computer Science and Engineering",
      "Information Science and Engineering",
      "Electronics and Communication Engineering",
      "Mechanical Engineering",
      "Civil Engineering",
      "Master of Business Administration"
    ],
    facilities: [
      "Library",
      "Sports Facilities",
      "Hostels",
      "Transportation",
      "Cafeteria",
      "Laboratories",
      "Placement Cell",
      "Entrepreneurship Development Cell"
    ],
    admissionProcess: "Atria Institute of Technology offers admissions through KCET and COMEDK entrance exams. Management quota seats are also available for direct admission. The process for management quota involves contacting the college directly and completing the admission process which includes document verification and fee payment.",
    feeStructure: "The annual fee for B.E. programs under management quota is approximately ₹1,25,000 to ₹1,75,000. For NRI quota, the fees are approximately ₹2,00,000 to ₹3,00,000 per annum.",
    eligibility: "For B.E. programs, candidates must have passed 10+2 with Physics, Chemistry, and Mathematics with a minimum aggregate of 45% marks (40% for SC/ST candidates).",
    contactInfo: {
      phone: "+91 8118935934",
      email: "info@bangaloreadmissionhub.com",
      website: "https://www.atria.edu",
      address: "ASKB Campus, 1st Main Rd, Anandnagar, Hebbal, Bengaluru - 560024, Karnataka, India"
    }
  },
  {
    id: "bms-institute",
    name: "BMS Institute of Technology and Management",
    shortDescription: "BMS Institute of Technology and Management is known for its quality education.",
    fullDescription: "BMS Institute of Technology and Management (BMSIT&M) was established in 2002 and is affiliated to Visvesvaraya Technological University (VTU) and approved by AICTE. The institute offers undergraduate, postgraduate, and doctoral programs in various engineering disciplines. BMSIT&M is known for its academic excellence, research focus, and industry connections. The college has modern infrastructure, well-equipped laboratories, and a conducive learning environment.",
    image: "https://ext.same-assets.com/2614824330/53880678.jpeg",
    location: "Yelahanka, Bengaluru",
    established: "2002",
    featured: false,
    courses: ["B.E. in Computer Science", "B.E. in Information Science", "B.E. in Electronics & Communication", "B.E. in Mechanical Engineering", "B.E. in Civil Engineering", "M.Tech Programs", "Ph.D Programs"],
    departments: [
      "Computer Science and Engineering",
      "Information Science and Engineering",
      "Electronics and Communication Engineering",
      "Electrical and Electronics Engineering",
      "Mechanical Engineering",
      "Civil Engineering",
      "Artificial Intelligence and Machine Learning",
      "Computer Science and Business Systems"
    ],
    facilities: [
      "Library",
      "Sports Complex",
      "Hostels",
      "Transportation",
      "Cafeteria",
      "Laboratories",
      "Placement Cell",
      "Research Centers"
    ],
    admissionProcess: "BMS Institute of Technology and Management offers admissions through KCET and COMEDK entrance exams. Management quota seats are also available for direct admission. The process for management quota involves contacting the college directly, attending counseling, and completing the admission process.",
    feeStructure: "The annual fee for B.E. programs under management quota is approximately ₹1,50,000 to ₹2,00,000. For NRI quota, the fees are approximately ₹2,50,000 to ₹3,50,000 per annum.",
    eligibility: "For B.E. programs, candidates must have passed 10+2 with Physics, Chemistry, and Mathematics with a minimum aggregate of 45% marks (40% for SC/ST candidates).",
    contactInfo: {
      phone: "+91 8118935934",
      email: "info@bangaloreadmissionhub.com",
      website: "https://www.bmsit.ac.in",
      address: "Doddaballapur Main Road, Avalahalli, Yelahanka, Bengaluru - 560064, Karnataka, India"
    }
  }
];
