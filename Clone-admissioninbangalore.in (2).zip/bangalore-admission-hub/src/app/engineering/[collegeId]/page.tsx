import { engineeringColleges } from "@/data/engineeringColleges";
import { CollegeDetailsPage } from "@/components/collegeDetails/CollegeDetailsPage";
import { notFound } from "next/navigation";

interface EngineeringCollegePageProps {
  params: {
    collegeId: string;
  };
}

export function generateStaticParams() {
  return engineeringColleges.map((college) => ({
    collegeId: college.id,
  }));
}

export default function EngineeringCollegePage({ params }: EngineeringCollegePageProps) {
  const college = engineeringColleges.find((college) => college.id === params.collegeId);

  if (!college) {
    return notFound();
  }

  // Get related colleges (exclude current college)
  const relatedColleges = engineeringColleges
    .filter((item) => item.id !== college.id)
    .slice(0, 4);

  return (
    <CollegeDetailsPage
      college={college}
      relatedColleges={relatedColleges}
      category="engineering"
    />
  );
}
