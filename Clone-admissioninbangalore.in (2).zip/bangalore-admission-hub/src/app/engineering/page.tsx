import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { EngineeringColleges } from "@/components/EngineeringColleges";

export default function EngineeringPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <div className="bg-slate-50 py-12">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center">Engineering Colleges in Bangalore</h1>
            <div className="w-24 h-1 bg-primary mx-auto mb-6" />
            <p className="text-center text-slate-600 max-w-3xl mx-auto mb-12">
              Explore top engineering colleges in Bangalore and get direct admission through management quota.
              We provide complete assistance in securing admission to the college of your choice.
            </p>
          </div>
        </div>

        <EngineeringColleges />

        <div className="bg-white py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold mb-6 text-center">Engineering Admission Process in Bangalore</h2>
            <div className="w-24 h-1 bg-primary mx-auto mb-12" />

            <div className="max-w-4xl mx-auto">
              <div className="space-y-8">
                <div className="bg-slate-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3 text-primary">Management Quota Admission</h3>
                  <p className="text-slate-600">
                    Management quota seats are reserved by the college management. These seats are filled at the
                    discretion of the management and don't require entrance exam scores. Students can apply
                    directly to colleges or through consultants like us to secure these seats.
                  </p>
                </div>

                <div className="bg-slate-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3 text-primary">NRI Quota Admission</h3>
                  <p className="text-slate-600">
                    NRI quota seats are reserved for Non-Resident Indians, Persons of Indian Origin (PIO),
                    and Overseas Citizens of India (OCI). These seats typically have higher fee structures
                    but provide easier entry to prestigious colleges.
                  </p>
                </div>

                <div className="bg-slate-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3 text-primary">Required Documents</h3>
                  <ul className="list-disc pl-6 space-y-1 text-slate-600">
                    <li>10th and 12th mark sheets and certificates</li>
                    <li>Transfer certificate</li>
                    <li>Migration certificate (if applicable)</li>
                    <li>Character certificate</li>
                    <li>Passport size photographs</li>
                    <li>ID proof (Aadhar card, passport, etc.)</li>
                    <li>Entrance exam scorecard (if applicable)</li>
                    <li>NRI/PIO/OCI documents (for NRI quota)</li>
                  </ul>
                </div>

                <div className="bg-slate-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3 text-primary">How We Help</h3>
                  <p className="text-slate-600 mb-4">
                    At Bangalore Admission Hub, we provide end-to-end assistance for securing admission in top
                    engineering colleges in Bangalore. Our services include:
                  </p>
                  <ul className="list-disc pl-6 space-y-1 text-slate-600">
                    <li>College selection guidance based on your preferences and eligibility</li>
                    <li>Documentation assistance</li>
                    <li>Direct communication with college management</li>
                    <li>Fee negotiation (when possible)</li>
                    <li>Guidance throughout the admission process</li>
                  </ul>
                </div>
              </div>

              <div className="mt-12 bg-primary/10 p-6 rounded-lg">
                <h3 className="text-xl font-semibold mb-3 text-center">Need Help with Engineering Admission?</h3>
                <p className="text-center text-slate-600 mb-4">
                  Contact us for personalized guidance and assistance in securing admission to
                  your preferred engineering college in Bangalore.
                </p>
                <div className="text-center">
                  <a href="tel:+918118935934" className="text-lg font-medium text-primary hover:underline">
                    Call us at +91 8118935934
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
