import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { HeroSection } from "@/components/HeroSection";
import { FeaturedColleges } from "@/components/FeaturedColleges";
import { WhyChooseUs } from "@/components/WhyChooseUs";
import { EngineeringColleges } from "@/components/EngineeringColleges";
import { DentalColleges } from "@/components/DentalColleges";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <HeroSection />
        <FeaturedColleges />
        <WhyChooseUs />
        <EngineeringColleges />
        <DentalColleges />
      </main>
      <Footer />
    </div>
  );
}
