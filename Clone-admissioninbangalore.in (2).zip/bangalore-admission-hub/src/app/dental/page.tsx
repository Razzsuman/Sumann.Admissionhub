import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { DentalColleges } from "@/components/DentalColleges";

export default function DentalPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <div className="bg-slate-50 py-12">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center">Dental Colleges in Bangalore</h1>
            <div className="w-24 h-1 bg-primary mx-auto mb-6" />
            <p className="text-center text-slate-600 max-w-3xl mx-auto mb-12">
              Explore top dental colleges in Bangalore and get direct admission through management quota.
              We provide complete assistance in securing admission to the dental college of your choice.
            </p>
          </div>
        </div>

        <DentalColleges />

        <div className="bg-white py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold mb-6 text-center">Dental Admission Process in Bangalore</h2>
            <div className="w-24 h-1 bg-primary mx-auto mb-12" />

            <div className="max-w-4xl mx-auto">
              <div className="space-y-8">
                <div className="bg-slate-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3 text-primary">Management Quota Admission</h3>
                  <p className="text-slate-600">
                    Management quota seats are reserved by the dental college management. These seats are filled at the
                    discretion of the management and offer a direct path to admission. Students can apply
                    directly to colleges or through consultants like us to secure these seats.
                  </p>
                </div>

                <div className="bg-slate-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3 text-primary">NEET Qualification</h3>
                  <p className="text-slate-600">
                    While management quota admissions may not require high NEET scores, candidates generally
                    need to have appeared for NEET and secured at least the minimum qualifying marks. The exact
                    requirements vary by college and year.
                  </p>
                </div>

                <div className="bg-slate-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3 text-primary">Required Documents</h3>
                  <ul className="list-disc pl-6 space-y-1 text-slate-600">
                    <li>10th and 12th mark sheets and certificates</li>
                    <li>NEET scorecard</li>
                    <li>Transfer certificate</li>
                    <li>Migration certificate (if applicable)</li>
                    <li>Character certificate</li>
                    <li>Passport size photographs</li>
                    <li>ID proof (Aadhar card, passport, etc.)</li>
                    <li>Caste certificate (if applicable)</li>
                  </ul>
                </div>

                <div className="bg-slate-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3 text-primary">Career Prospects</h3>
                  <p className="text-slate-600 mb-4">
                    A BDS (Bachelor of Dental Surgery) degree opens various career paths:
                  </p>
                  <ul className="list-disc pl-6 space-y-1 text-slate-600">
                    <li>Private dental practice</li>
                    <li>Hospital dentistry</li>
                    <li>Academic careers in dental colleges</li>
                    <li>Research in dental sciences</li>
                    <li>Specialization through MDS (Master of Dental Surgery)</li>
                    <li>Opportunities in government health services</li>
                  </ul>
                </div>

                <div className="bg-slate-50 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3 text-primary">How We Help</h3>
                  <p className="text-slate-600 mb-4">
                    At Bangalore Admission Hub, we provide comprehensive assistance for securing admission in top
                    dental colleges in Bangalore. Our services include:
                  </p>
                  <ul className="list-disc pl-6 space-y-1 text-slate-600">
                    <li>College selection guidance based on your NEET score and preferences</li>
                    <li>Documentation assistance</li>
                    <li>Direct communication with college management</li>
                    <li>Fee structure guidance</li>
                    <li>Support throughout the admission process</li>
                  </ul>
                </div>
              </div>

              <div className="mt-12 bg-primary/10 p-6 rounded-lg">
                <h3 className="text-xl font-semibold mb-3 text-center">Need Help with Dental Admission?</h3>
                <p className="text-center text-slate-600 mb-4">
                  Contact us for personalized guidance and assistance in securing admission to
                  your preferred dental college in Bangalore.
                </p>
                <div className="text-center">
                  <a href="tel:+918118935934" className="text-lg font-medium text-primary hover:underline">
                    Call us at +91 8118935934
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
