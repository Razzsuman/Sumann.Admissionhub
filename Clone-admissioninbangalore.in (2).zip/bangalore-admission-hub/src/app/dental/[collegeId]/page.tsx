import { dentalColleges } from "@/data/dentalColleges";
import { CollegeDetailsPage } from "@/components/collegeDetails/CollegeDetailsPage";
import { notFound } from "next/navigation";

interface DentalCollegePageProps {
  params: {
    collegeId: string;
  };
}

export function generateStaticParams() {
  return dentalColleges.map((college) => ({
    collegeId: college.id,
  }));
}

export default function DentalCollegePage({ params }: DentalCollegePageProps) {
  const college = dentalColleges.find((college) => college.id === params.collegeId);

  if (!college) {
    return notFound();
  }

  // Get related colleges (exclude current college)
  const relatedColleges = dentalColleges
    .filter((item) => item.id !== college.id)
    .slice(0, 4);

  return (
    <CollegeDetailsPage
      college={college}
      relatedColleges={relatedColleges}
      category="dental"
    />
  );
}
