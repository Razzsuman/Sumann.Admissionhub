import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export default function AboutPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <div className="bg-slate-50 py-12 md:py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center">About Bangalore Admission Hub</h1>
            <div className="w-24 h-1 bg-primary mx-auto mb-12" />

            <div className="max-w-4xl mx-auto">
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <h2 className="text-2xl font-semibold mb-6 text-primary">Our Mission</h2>
                <p className="text-slate-700 mb-8 leading-relaxed">
                  At Bangalore Admission Hub, our mission is to provide hassle-free admission guidance to students seeking quality education in Bangalore's top institutions.
                  We aim to bridge the gap between aspiring students and prestigious educational institutions through our expertise and strong network.
                </p>

                <h2 className="text-2xl font-semibold mb-6 text-primary">Who We Are</h2>
                <p className="text-slate-700 mb-8 leading-relaxed">
                  Bangalore Admission Hub is a leading education consultancy specializing in providing direct admissions to top engineering and dental colleges in Bangalore.
                  With years of experience in the education sector, we have established ourselves as a trusted partner for students and parents navigating the complex admission process.
                </p>

                <h2 className="text-2xl font-semibold mb-6 text-primary">Our Services</h2>
                <ul className="list-disc pl-6 mb-8 space-y-3 text-slate-700 leading-relaxed">
                  <li><span className="font-medium">Direct Admission Guidance:</span> We provide end-to-end admission guidance for securing seats through management quota in top colleges.</li>
                  <li><span className="font-medium">College Selection:</span> We help students choose the right college based on their preferences, budget, and career goals.</li>
                  <li><span className="font-medium">Documentation Support:</span> We assist in preparing and organizing all necessary documents required for the admission process.</li>
                  <li><span className="font-medium">Scholarship Guidance:</span> We provide information about available scholarships and help students apply for them.</li>
                  <li><span className="font-medium">Career Counseling:</span> Our experts offer career counseling to help students make informed decisions about their academic future.</li>
                </ul>

                <h2 className="text-2xl font-semibold mb-6 text-primary">Why Choose Us</h2>
                <ul className="list-disc pl-6 mb-8 space-y-3 text-slate-700 leading-relaxed">
                  <li><span className="font-medium">Expertise:</span> Our team has extensive knowledge of the admission processes of various colleges in Bangalore.</li>
                  <li><span className="font-medium">Network:</span> We have strong relationships with top engineering and dental colleges in Bangalore.</li>
                  <li><span className="font-medium">Transparency:</span> We maintain complete transparency in our dealings, providing clear information about fees and admission procedures.</li>
                  <li><span className="font-medium">Success Rate:</span> We have a high success rate in securing admissions for our students in their preferred colleges.</li>
                  <li><span className="font-medium">Personalized Approach:</span> We understand that each student is unique, and we provide personalized guidance tailored to individual needs.</li>
                </ul>

                <h2 className="text-2xl font-semibold mb-6 text-primary">Contact Us</h2>
                <p className="text-slate-700 leading-relaxed">
                  Have questions or need more information? Contact us at <a href="tel:+918118935934" className="text-primary hover:underline">+91 8118935934</a> or email us at <a href="mailto:info@bangaloreadmissionhub.com" className="text-primary hover:underline">info@bangaloreadmissionhub.com</a>.
                  Our team is always ready to assist you in your educational journey.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
