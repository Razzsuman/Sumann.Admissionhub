"use client";

import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import Image from "next/image";
import { Building, MapPin, Trophy, GraduationCap, Zap } from "lucide-react";

interface CollegeCardProps {
  id: string;
  name: string;
  image: string;
  shortDescription: string;
  location: string;
  ranking?: string;
  established?: string;
  category: "engineering" | "dental";
  featured?: boolean;
}

export function CollegeCard({
  id,
  name,
  image,
  shortDescription,
  location,
  ranking,
  established,
  category,
  featured = false,
}: CollegeCardProps) {
  const collegeLink = `/${category}/${id}`;

  return (
    <div className="group relative overflow-hidden rounded-xl border bg-white shadow-sm transition-all duration-300 hover:shadow-xl">
      {featured && (
        <div className="absolute right-0 top-0 z-10">
          <Badge className="rounded-none rounded-bl-lg bg-primary px-3 py-1.5 text-xs font-medium text-white">
            Featured
          </Badge>
        </div>
      )}

      <div className="relative h-56 w-full overflow-hidden">
        <Image
          src={image}
          alt={name}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-110"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      </div>

      <div className="p-5">
        <div className="mb-3 flex items-center gap-1 text-xs text-slate-500">
          <MapPin size={14} className="text-primary" />
          <span>{location}</span>
          {established && (
            <>
              <span className="mx-1 text-slate-300">•</span>
              <Building size={14} className="text-primary" />
              <span>Est. {established}</span>
            </>
          )}
          {ranking && (
            <>
              <span className="mx-1 text-slate-300">•</span>
              <Trophy size={14} className="text-primary" />
              <span>{ranking}</span>
            </>
          )}
        </div>

        <h3 className="mb-2 text-xl font-bold text-slate-800 line-clamp-2 group-hover:text-primary transition-colors">
          {name}
        </h3>

        <p className="mb-4 text-sm text-slate-600 line-clamp-2">
          {shortDescription}
        </p>

        <div className="flex flex-wrap gap-2 mb-4">
          <Badge variant="outline" className="bg-primary/5 border-primary/20 text-primary text-xs">
            <GraduationCap size={12} className="mr-1" />
            Direct Admission
          </Badge>
          <Badge variant="outline" className="bg-primary/5 border-primary/20 text-primary text-xs">
            <Zap size={12} className="mr-1" />
            Management Quota
          </Badge>
        </div>

        <Link
          href={collegeLink}
          className="inline-flex w-full items-center justify-center rounded-lg bg-primary/10 px-4 py-2 text-sm font-medium text-primary transition-colors hover:bg-primary hover:text-white"
        >
          View College Details
        </Link>
      </div>
    </div>
  );
}
