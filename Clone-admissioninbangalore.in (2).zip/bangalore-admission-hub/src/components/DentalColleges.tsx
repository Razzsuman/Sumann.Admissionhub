"use client";

import { dentalColleges } from "@/data/dentalColleges";
import { CollegeCard } from "@/components/CollegeCard";

export function DentalColleges() {
  return (
    <section className="py-16 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">TOP DENTAL COLLEGES IN BANGALORE</h2>
          <div className="w-24 h-1 bg-primary mx-auto mb-6" />
          <p className="text-slate-600 max-w-2xl mx-auto mb-8">
            Explore top dental colleges in Bangalore for direct admission through management quota.
            We help you secure admission in the dental college of your choice.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {dentalColleges.map((college) => (
            <CollegeCard
              key={college.id}
              id={college.id}
              name={college.name}
              image={college.image}
              shortDescription={college.shortDescription}
              location={college.location}
              ranking={college.ranking}
              established={college.established}
              category="dental"
              featured={college.featured}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
