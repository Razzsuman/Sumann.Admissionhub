"use client";

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import Image from "next/image";

const featuredColleges = [
  {
    id: 1,
    name: "RV College Of Engineering",
    description: "Rashtreeya Vidyalaya College of Engineering (RVCE) is a private autonomous college in Bangalore.",
    image: "https://ext.same-assets.com/2614824330/1545761655.jpeg",
    link: "/engineering/rv-college",
  },
  {
    id: 2,
    name: "BMS College of Engineering",
    description: "BMS College of Engineering (BMSCE) is an autonomous engineering college in Bangalore.",
    image: "https://ext.same-assets.com/2614824330/136836748.jpeg",
    link: "/engineering/bms-college",
  },
  {
    id: 3,
    name: "MS Ramaiah Institute of Technology",
    description: "Located in Bengaluru, Ramaiah Institute of Technology (RIT) is a leading institution.",
    image: "https://ext.same-assets.com/2614824330/584414836.jpeg",
    link: "/engineering/ms-ramaiah",
  },
  {
    id: 4,
    name: "Dayananda Sagar College Of Engineering",
    description: "Established in 1979, Dayananda Sagar College of Engineering (DSCE) is a prestigious college.",
    image: "https://ext.same-assets.com/2614824330/3181667196.jpeg",
    link: "/engineering/dayananda-sagar",
  },
];

export function FeaturedColleges() {
  return (
    <section className="py-16 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Featured Colleges</h2>
          <div className="w-24 h-1 bg-primary mx-auto mb-6" />
          <p className="text-slate-600 max-w-2xl mx-auto">
            Explore top engineering and dental colleges in Bangalore for direct admissions through management quota.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {featuredColleges.map((college) => (
            <Card key={college.id} className="overflow-hidden transition-all hover:shadow-lg">
              <div className="relative h-48 w-full">
                <Image
                  src={college.image}
                  alt={college.name}
                  fill
                  style={{ objectFit: "cover" }}
                />
              </div>
              <CardHeader className="p-4">
                <CardTitle className="text-lg">{college.name}</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <CardDescription className="text-sm text-slate-600">
                  {college.description}
                </CardDescription>
              </CardContent>
              <CardFooter className="p-4 pt-0">
                <Link href={college.link} className="w-full">
                  <Button variant="secondary" className="w-full">Read More</Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
