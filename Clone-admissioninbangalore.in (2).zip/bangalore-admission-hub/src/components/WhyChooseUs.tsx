"use client";

import { CheckCircle2, Briefcase, CreditCard, BarChart } from "lucide-react";

const features = [
  {
    id: "direct-admissions",
    icon: <CheckCircle2 className="w-10 h-10 text-primary" />,
    title: "Direct Admissions",
    description: "We provide direct admission to top colleges in Bangalore without any entrance exams.",
  },
  {
    id: "management-quota",
    icon: <Briefcase className="w-10 h-10 text-primary" />,
    title: "Management Quota",
    description: "Secure your seat through management quota in prestigious engineering and dental colleges.",
  },
  {
    id: "affordable-education",
    icon: <CreditCard className="w-10 h-10 text-primary" />,
    title: "Affordable Education",
    description: "We help you find colleges with reasonable fee structures and quality education.",
  },
  {
    id: "on-spot-admissions",
    icon: <BarChart className="w-10 h-10 text-primary" />,
    title: "On Spot Admissions",
    description: "Get on-the-spot admission confirmation with our streamlined process.",
  },
];

export function WhyChooseUs() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Why Choose Us</h2>
          <div className="w-24 h-1 bg-primary mx-auto mb-6" />
          <p className="text-slate-600 max-w-2xl mx-auto">
            Bangalore Admission Hub is your trusted partner for securing admissions in top colleges across Bangalore.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <div key={feature.id} className="bg-slate-50 p-6 rounded-lg text-center transition-all hover:shadow-lg">
              <div className="mb-4 flex justify-center">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-slate-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
