"use client";

import Link from "next/link";
import { Phone, Mail, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-slate-900 text-white">
      <div className="container px-4 py-16 mx-auto md:px-8">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <h3 className="mb-4 text-xl font-bold">Bangalore Admission Hub</h3>
            <p className="mb-4 text-slate-300">
              We help students get direct admission in best colleges in Bangalore through Management Quota
              and other professional degree courses.
            </p>
            <div className="flex items-center gap-2 mb-2">
              <Phone size={16} className="text-primary" />
              <a href="tel:+918118935934" className="text-slate-300 hover:text-primary">
                +91 8118935934
              </a>
            </div>
            <div className="flex items-center gap-2 mb-2">
              <Mail size={16} className="text-primary" />
              <a href="mailto:info@bangaloreadmissionhub.com" className="text-slate-300 hover:text-primary">
                info@bangaloreadmissionhub.com
              </a>
            </div>
            <div className="flex items-start gap-2">
              <MapPin size={16} className="text-primary mt-1" />
              <span className="text-slate-300">
                Bangalore, Karnataka, India
              </span>
            </div>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-semibold">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-slate-300 hover:text-primary">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-slate-300 hover:text-primary">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/engineering" className="text-slate-300 hover:text-primary">
                  Engineering Colleges
                </Link>
              </li>
              <li>
                <Link href="/dental" className="text-slate-300 hover:text-primary">
                  Dental Colleges
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-slate-300 hover:text-primary">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-semibold">Top Engineering Colleges</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/engineering/rv-college" className="text-slate-300 hover:text-primary">
                  RV College of Engineering
                </Link>
              </li>
              <li>
                <Link href="/engineering/bms-college" className="text-slate-300 hover:text-primary">
                  BMS College of Engineering
                </Link>
              </li>
              <li>
                <Link href="/engineering/ms-ramaiah" className="text-slate-300 hover:text-primary">
                  MS Ramaiah Institute of Technology
                </Link>
              </li>
              <li>
                <Link href="/engineering/dayananda-sagar" className="text-slate-300 hover:text-primary">
                  Dayananda Sagar College of Engineering
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-semibold">Top Dental Colleges</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/dental/bangalore-institute" className="text-slate-300 hover:text-primary">
                  Bangalore Institute of Dental Science
                </Link>
              </li>
              <li>
                <Link href="/dental/rv-dental" className="text-slate-300 hover:text-primary">
                  RV Dental College
                </Link>
              </li>
              <li>
                <Link href="/dental/ms-ramaiah-dental" className="text-slate-300 hover:text-primary">
                  MS Ramaiah Dental College
                </Link>
              </li>
              <li>
                <Link href="/dental/vydehi-institute" className="text-slate-300 hover:text-primary">
                  Vydehi Institute of Dental Sciences
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 mt-8 border-t border-gray-700">
          <p className="text-center text-slate-400">
            &copy; {new Date().getFullYear()} Bangalore Admission Hub. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
