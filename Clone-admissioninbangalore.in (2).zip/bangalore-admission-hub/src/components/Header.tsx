"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Menu, X, Phone } from "lucide-react";

const navLinks = [
  { name: "Home", path: "/" },
  { name: "About Us", path: "/about" },
  { name: "Engineering", path: "/engineering" },
  { name: "Dental Colleges", path: "/dental" },
  { name: "Contact Us", path: "/contact" },
];

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background">
      <div className="container flex h-16 items-center justify-between py-4">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center">
            <span className="text-xl font-bold text-primary">Bangalore Admission Hub</span>
          </Link>
        </div>

        <div className="hidden md:flex items-center gap-6">
          <nav className="flex items-center gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                href={link.path}
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                {link.name}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Phone size={16} className="text-primary" />
            <a href="tel:+918118935934" className="text-sm font-medium">
              +91 8118935934
            </a>
          </div>
        </div>

        <div className="flex md:hidden">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </Button>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 top-16 z-50 flex h-[calc(100vh-4rem)] flex-col bg-background p-6 md:hidden">
          <nav className="flex flex-col gap-6 text-lg">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                href={link.path}
                onClick={() => setIsMenuOpen(false)}
                className="text-muted-foreground hover:text-primary"
              >
                {link.name}
              </Link>
            ))}
          </nav>
          <div className="mt-auto">
            <div className="flex items-center gap-2 border-t pt-4">
              <Phone size={16} className="text-primary" />
              <a href="tel:+918118935934" className="text-sm font-medium">
                +91 8118935934
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
