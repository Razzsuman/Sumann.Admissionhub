"use client";

import type { College } from "@/data/engineeringColleges";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import Image from "next/image";
import {
  Building,
  Calendar,
  Trophy,
  BookOpen,
  Layers,
  LandPlot,
  GraduationCap,
  BadgeDollarSign,
  ClipboardCheck,
  Phone,
  Mail,
  Globe,
  MapPin,
  ChevronRight,
  Zap
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { type FormEvent, useState } from "react";

interface CollegeDetailsPageProps {
  college: College;
  relatedColleges: College[];
  category: "engineering" | "dental";
}

export function CollegeDetailsPage({ college, relatedColleges, category }: CollegeDetailsPageProps) {
  const [activeTab, setActiveTab] = useState<string>("about");
  const [contactFormData, setContactFormData] = useState({
    name: "",
    phone: "",
    email: "",
    message: ""
  });

  const handleContactFormSubmit = (e: FormEvent) => {
    e.preventDefault();
    alert("Thank you for your enquiry. We will contact you soon!");
    setContactFormData({
      name: "",
      phone: "",
      email: "",
      message: ""
    });
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <div className="relative bg-slate-900 text-white">
          <div className="absolute inset-0 opacity-20">
            <Image
              src={college.image}
              alt={college.name}
              fill
              className="object-cover"
              priority
            />
          </div>
          <div className="relative container mx-auto px-4 py-16 md:py-24">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              {college.name}
            </h1>
            <div className="flex flex-wrap items-center gap-3 mb-6">
              <Badge variant="secondary" className="bg-white/20 text-white">
                {category === "engineering" ? "Engineering College" : "Dental College"}
              </Badge>
              {college.established && (
                <Badge variant="outline" className="border-white/30 text-white">
                  <Calendar size={14} className="mr-1" />
                  Est. {college.established}
                </Badge>
              )}
              {college.ranking && (
                <Badge variant="outline" className="border-white/30 text-white">
                  <Trophy size={14} className="mr-1" />
                  {college.ranking}
                </Badge>
              )}
              <Badge variant="outline" className="border-white/30 text-white">
                <MapPin size={14} className="mr-1" />
                {college.location}
              </Badge>
            </div>
            <p className="text-lg text-white/80 max-w-3xl">
              {college.shortDescription}
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="sticky top-16 z-20 bg-white border-b shadow-sm">
          <div className="container mx-auto px-4">
            <div className="flex overflow-x-auto">
              <button
                onClick={() => setActiveTab("about")}
                className={`px-4 py-3 font-medium text-sm whitespace-nowrap border-b-2 ${
                  activeTab === "about" ? "border-primary text-primary" : "border-transparent text-slate-600 hover:text-slate-900"
                }`}
              >
                About College
              </button>
              <button
                onClick={() => setActiveTab("courses")}
                className={`px-4 py-3 font-medium text-sm whitespace-nowrap border-b-2 ${
                  activeTab === "courses" ? "border-primary text-primary" : "border-transparent text-slate-600 hover:text-slate-900"
                }`}
              >
                Courses & Departments
              </button>
              <button
                onClick={() => setActiveTab("facilities")}
                className={`px-4 py-3 font-medium text-sm whitespace-nowrap border-b-2 ${
                  activeTab === "facilities" ? "border-primary text-primary" : "border-transparent text-slate-600 hover:text-slate-900"
                }`}
              >
                Facilities
              </button>
              <button
                onClick={() => setActiveTab("admission")}
                className={`px-4 py-3 font-medium text-sm whitespace-nowrap border-b-2 ${
                  activeTab === "admission" ? "border-primary text-primary" : "border-transparent text-slate-600 hover:text-slate-900"
                }`}
              >
                Admission Process
              </button>
              <button
                onClick={() => setActiveTab("fees")}
                className={`px-4 py-3 font-medium text-sm whitespace-nowrap border-b-2 ${
                  activeTab === "fees" ? "border-primary text-primary" : "border-transparent text-slate-600 hover:text-slate-900"
                }`}
              >
                Fee Structure
              </button>
              <button
                onClick={() => setActiveTab("contact")}
                className={`px-4 py-3 font-medium text-sm whitespace-nowrap border-b-2 ${
                  activeTab === "contact" ? "border-primary text-primary" : "border-transparent text-slate-600 hover:text-slate-900"
                }`}
              >
                Contact
              </button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="py-8 md:py-12">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-3 gap-8">
              {/* Content Area */}
              <div className="md:col-span-2">
                {/* About Section */}
                {activeTab === "about" && (
                  <div>
                    <h2 className="text-2xl font-bold mb-6">About {college.name}</h2>
                    <div className="mb-8">
                      <div className="relative h-80 w-full mb-6 rounded-lg overflow-hidden shadow-md">
                        <Image
                          src={college.image}
                          alt={college.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="prose max-w-none">
                        <p className="text-slate-700 leading-relaxed whitespace-pre-line">
                          {college.fullDescription}
                        </p>
                      </div>
                    </div>

                    {college.established && (
                      <div className="flex items-center gap-2 mb-4 text-slate-700">
                        <div className="bg-primary/10 p-2 rounded">
                          <Calendar className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <span className="font-medium">Established:</span> {college.established}
                        </div>
                      </div>
                    )}

                    {college.ranking && (
                      <div className="flex items-center gap-2 mb-4 text-slate-700">
                        <div className="bg-primary/10 p-2 rounded">
                          <Trophy className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <span className="font-medium">Ranking:</span> {college.ranking}
                        </div>
                      </div>
                    )}

                    <div className="flex items-center gap-2 mb-4 text-slate-700">
                      <div className="bg-primary/10 p-2 rounded">
                        <MapPin className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">Location:</span> {college.location}
                      </div>
                    </div>
                  </div>
                )}

                {/* Courses & Departments Section */}
                {activeTab === "courses" && (
                  <div>
                    <h2 className="text-2xl font-bold mb-6">Courses & Departments</h2>

                    {college.courses && college.courses.length > 0 && (
                      <div className="mb-8">
                        <h3 className="text-xl font-semibold mb-4 flex items-center">
                          <BookOpen className="h-5 w-5 mr-2 text-primary" />
                          Courses Offered
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {college.courses.map((course, index) => (
                            <div key={index} className="flex items-center p-3 bg-slate-50 rounded-lg">
                              <GraduationCap className="h-5 w-5 mr-3 text-primary" />
                              <span>{course}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {college.departments && college.departments.length > 0 && (
                      <div>
                        <h3 className="text-xl font-semibold mb-4 flex items-center">
                          <Layers className="h-5 w-5 mr-2 text-primary" />
                          Departments
                        </h3>
                        <div className="grid grid-cols-1 gap-3">
                          {college.departments.map((department, index) => (
                            <div key={index} className="flex items-center p-3 bg-slate-50 rounded-lg">
                              <div className="h-6 w-6 flex items-center justify-center bg-primary text-white rounded-full text-xs mr-3">
                                {index + 1}
                              </div>
                              <span>{department}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Facilities Section */}
                {activeTab === "facilities" && (
                  <div>
                    <h2 className="text-2xl font-bold mb-6">Facilities</h2>

                    {college.facilities && college.facilities.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {college.facilities.map((facility, index) => (
                          <div key={index} className="flex items-start p-4 bg-slate-50 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                            <div className="bg-primary/10 p-2 rounded mr-3">
                              <LandPlot className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <h4 className="font-medium">{facility}</h4>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-slate-600">Information about facilities is not available.</p>
                    )}
                  </div>
                )}

                {/* Admission Process Section */}
                {activeTab === "admission" && (
                  <div>
                    <h2 className="text-2xl font-bold mb-6">Admission Process</h2>

                    <div className="mb-8">
                      <h3 className="text-xl font-semibold mb-4 flex items-center">
                        <ClipboardCheck className="h-5 w-5 mr-2 text-primary" />
                        How to Get Admission
                      </h3>
                      <div className="p-6 bg-slate-50 rounded-lg">
                        {college.admissionProcess ? (
                          <p className="text-slate-700 leading-relaxed whitespace-pre-line">
                            {college.admissionProcess}
                          </p>
                        ) : (
                          <p className="text-slate-600">Detailed admission process information is not available. Please contact us for more information.</p>
                        )}
                      </div>
                    </div>

                    <div className="mb-8">
                      <h3 className="text-xl font-semibold mb-4 flex items-center">
                        <GraduationCap className="h-5 w-5 mr-2 text-primary" />
                        Eligibility Criteria
                      </h3>
                      <div className="p-6 bg-slate-50 rounded-lg">
                        {college.eligibility ? (
                          <p className="text-slate-700 leading-relaxed whitespace-pre-line">
                            {college.eligibility}
                          </p>
                        ) : (
                          <p className="text-slate-600">Detailed eligibility criteria information is not available. Please contact us for more information.</p>
                        )}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-xl font-semibold mb-4 flex items-center">
                        <Zap className="h-5 w-5 mr-2 text-primary" />
                        Management Quota Admission
                      </h3>
                      <div className="p-6 bg-primary/5 rounded-lg border border-primary/10">
                        <p className="text-slate-700 leading-relaxed mb-4">
                          Looking for direct admission through management quota? Our admission counselors can help you secure a seat in {college.name}.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-4">
                          <Button
                            onClick={() => setActiveTab("contact")}
                            className="bg-primary hover:bg-primary/90"
                          >
                            Contact for Management Quota
                          </Button>
                          <a href={`tel:${college.contactInfo?.phone || "+918118935934"}`} className="inline-flex items-center justify-center rounded-lg bg-primary/10 px-4 py-2 text-sm font-medium text-primary transition-colors hover:bg-primary hover:text-white">
                            <Phone className="h-4 w-4 mr-2" />
                            Call Now
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Fee Structure Section */}
                {activeTab === "fees" && (
                  <div>
                    <h2 className="text-2xl font-bold mb-6">Fee Structure</h2>

                    <div className="mb-8">
                      <h3 className="text-xl font-semibold mb-4 flex items-center">
                        <BadgeDollarSign className="h-5 w-5 mr-2 text-primary" />
                        Fee Details
                      </h3>
                      <div className="p-6 bg-slate-50 rounded-lg">
                        {college.feeStructure ? (
                          <p className="text-slate-700 leading-relaxed whitespace-pre-line">
                            {college.feeStructure}
                          </p>
                        ) : (
                          <p className="text-slate-600">Detailed fee structure information is not available. Please contact us for more information.</p>
                        )}
                      </div>

                      <div className="mt-6 p-6 bg-amber-50 rounded-lg border border-amber-100">
                        <p className="text-slate-700 leading-relaxed mb-4">
                          <strong>Note:</strong> Fees are subject to change as per the college's policy. For the most up-to-date information, please contact our admission counselors.
                        </p>
                        <Button
                          onClick={() => setActiveTab("contact")}
                          className="bg-primary hover:bg-primary/90"
                        >
                          Contact for Fee Details
                        </Button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Contact Section */}
                {activeTab === "contact" && (
                  <div>
                    <h2 className="text-2xl font-bold mb-6">Contact Information</h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                      {college.contactInfo?.phone && (
                        <div className="flex items-start p-4 bg-slate-50 rounded-lg">
                          <div className="bg-primary/10 p-2 rounded mr-3">
                            <Phone className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-medium mb-1">Phone</h4>
                            <a href={`tel:${college.contactInfo.phone}`} className="text-primary hover:underline">
                              {college.contactInfo.phone}
                            </a>
                          </div>
                        </div>
                      )}

                      {college.contactInfo?.email && (
                        <div className="flex items-start p-4 bg-slate-50 rounded-lg">
                          <div className="bg-primary/10 p-2 rounded mr-3">
                            <Mail className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-medium mb-1">Email</h4>
                            <a href={`mailto:${college.contactInfo.email}`} className="text-primary hover:underline">
                              {college.contactInfo.email}
                            </a>
                          </div>
                        </div>
                      )}

                      {college.contactInfo?.website && (
                        <div className="flex items-start p-4 bg-slate-50 rounded-lg">
                          <div className="bg-primary/10 p-2 rounded mr-3">
                            <Globe className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-medium mb-1">Website</h4>
                            <a href={college.contactInfo.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                              {college.contactInfo.website.replace('https://', '')}
                            </a>
                          </div>
                        </div>
                      )}

                      {college.contactInfo?.address && (
                        <div className="flex items-start p-4 bg-slate-50 rounded-lg">
                          <div className="bg-primary/10 p-2 rounded mr-3">
                            <MapPin className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-medium mb-1">Address</h4>
                            <p className="text-slate-700">{college.contactInfo.address}</p>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="p-6 bg-slate-50 rounded-lg shadow-sm">
                      <h3 className="text-xl font-semibold mb-4">Send Enquiry</h3>
                      <form onSubmit={handleContactFormSubmit}>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1">
                              Name
                            </label>
                            <input
                              type="text"
                              id="name"
                              value={contactFormData.name}
                              onChange={(e) => setContactFormData({...contactFormData, name: e.target.value})}
                              required
                              className="w-full p-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary/20 focus:border-primary"
                            />
                          </div>
                          <div>
                            <label htmlFor="phone" className="block text-sm font-medium text-slate-700 mb-1">
                              Phone Number
                            </label>
                            <input
                              type="tel"
                              id="phone"
                              value={contactFormData.phone}
                              onChange={(e) => setContactFormData({...contactFormData, phone: e.target.value})}
                              required
                              className="w-full p-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary/20 focus:border-primary"
                            />
                          </div>
                        </div>
                        <div className="mb-4">
                          <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">
                            Email
                          </label>
                          <input
                            type="email"
                            id="email"
                            value={contactFormData.email}
                            onChange={(e) => setContactFormData({...contactFormData, email: e.target.value})}
                            required
                            className="w-full p-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary/20 focus:border-primary"
                          />
                        </div>
                        <div className="mb-4">
                          <label htmlFor="message" className="block text-sm font-medium text-slate-700 mb-1">
                            Message
                          </label>
                          <textarea
                            id="message"
                            value={contactFormData.message}
                            onChange={(e) => setContactFormData({...contactFormData, message: e.target.value})}
                            required
                            rows={4}
                            className="w-full p-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary/20 focus:border-primary"
                          ></textarea>
                        </div>
                        <Button type="submit" className="w-full">
                          Submit Enquiry
                        </Button>
                      </form>
                    </div>
                  </div>
                )}
              </div>

              {/* Sidebar */}
              <div className="md:col-span-1">
                {/* Quick Contact */}
                <div className="bg-white border rounded-lg p-6 shadow-sm mb-8">
                  <h3 className="text-lg font-semibold mb-4">Quick Contact</h3>
                  <div className="space-y-4 mb-6">
                    <div className="flex items-center">
                      <Phone className="h-5 w-5 text-primary mr-3" />
                      <a href={`tel:${college.contactInfo?.phone || "+918118935934"}`} className="text-slate-700 hover:text-primary">
                        {college.contactInfo?.phone || "+91 8118935934"}
                      </a>
                    </div>
                    <div className="flex items-center">
                      <Mail className="h-5 w-5 text-primary mr-3" />
                      <a href={`mailto:${college.contactInfo?.email || "info@bangaloreadmissionhub.com"}`} className="text-slate-700 hover:text-primary truncate">
                        {college.contactInfo?.email || "info@bangaloreadmissionhub.com"}
                      </a>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <Button
                      onClick={() => setActiveTab("contact")}
                      className="w-full bg-primary hover:bg-primary/90"
                    >
                      Contact for Admission
                    </Button>
                    <a
                      href={`tel:${college.contactInfo?.phone || "+918118935934"}`}
                      className="inline-flex w-full items-center justify-center rounded-lg bg-primary/10 px-4 py-2 text-sm font-medium text-primary transition-colors hover:bg-primary hover:text-white"
                    >
                      <Phone className="h-4 w-4 mr-2" />
                      Call Now
                    </a>
                  </div>
                </div>

                {/* Related Colleges */}
                <div className="bg-white border rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-semibold mb-4">Other {category === "engineering" ? "Engineering" : "Dental"} Colleges</h3>
                  <div className="space-y-3">
                    {relatedColleges.map((item) => (
                      <Link
                        key={item.id}
                        href={`/${category}/${item.id}`}
                        className="block p-3 rounded-lg hover:bg-slate-50 transition-colors"
                      >
                        <div className="flex items-center">
                          <div className="relative h-12 w-12 rounded-md overflow-hidden mr-3">
                            <Image
                              src={item.image}
                              alt={item.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="text-sm font-medium text-slate-800 truncate">{item.name}</h4>
                            <p className="text-xs text-slate-500 truncate">{item.location}</p>
                          </div>
                          <ChevronRight className="h-4 w-4 text-slate-400" />
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
